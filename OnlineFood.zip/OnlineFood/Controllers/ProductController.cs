﻿using Microsoft.AspNetCore.Mvc;
using OnlineFood.Data;
using OnlineFood.Models;
using System.Numerics;

namespace OnlineFood.Controllers
{
    [Route("api/product")]
    [ApiController]
    public class ProductController:ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IActionResult GetProductDetails() => Ok(_context.Products.ToList());


        [HttpPost("add")]
        public IActionResult AddProduct([FromBody]Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
            return Ok(new { message = "Product added succesfully" });
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null)
            return NotFound();
            _context.Products.Remove(product);
            _context.SaveChanges();
            return Ok(new { message = "product deleted" });
        }



    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace OnlineFood.Controllers
{
    [Route("api/payment")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        [HttpPost]
        public IActionResult ProcessPayment([FromBody] dynamic paymentData)
        {
            return Ok(new { status = "payment succesful", transctionId = Guid.NewGuid() });



        }
    }
}

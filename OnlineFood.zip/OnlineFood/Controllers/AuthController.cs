﻿using Microsoft.AspNetCore.Mvc;
using OnlineFood.Data;
using OnlineFood.Models;


[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    public AuthController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost("register")]
    public IActionResult Register([FromBody] User user)
    {
        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(user.Password);
        _context.Users.Add(user);
        _context.SaveChanges();
        return Ok("User registered successfully");
    }




    [HttpPost("login")]
    public IActionResult Login([FromBody] User input)
    {
        var user = _context.Users.FirstOrDefault(u => u.Email == input.Email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(input.Password, user.PasswordHash))
        {
            return Unauthorized("Invalid credentials");
        }

        return Ok(new { token = "fake-jwt-token" });
    }

}

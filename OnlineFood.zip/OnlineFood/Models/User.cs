﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineFood.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string Role { get; set; }//"Admin" or "Customer"

        [NotMapped]  // Ensures this field is not saved in the database
        public string Password { get; set; }


    }
}

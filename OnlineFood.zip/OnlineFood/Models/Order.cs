﻿namespace OnlineFood.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int userId {  get; set; }
        public int ProductId {  get; set; }
        public DateTime OrderDate { get; set; }
        public string status { get; set; }//"Pending" ,"Delivered"
    }
}

import React from 'react';

const ProductList = ({ products }) => {
  return (
    <div className="container mt-4">
      <h4 className="mb-3 text-center text-info">Available Products</h4>
      {products && products.length > 0 ? (
        <div className="table-responsive">
          <table className="table table-bordered table-hover">
            <thead className="table-light">
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Price (₹)</th>
                <th>Category</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{p.name}</td>
                  <td>{p.price}</td>
                  <td>{p.category}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="alert alert-warning text-center">No products available</div>
      )}
    </div>
  );
};

export default ProductList;

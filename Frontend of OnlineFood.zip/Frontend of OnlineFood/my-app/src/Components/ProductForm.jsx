import React, { useState } from 'react';

const ProductForm = ({ onSubmit }) => {
  const [product, setProduct] = useState({
    name: '',
    price: '',
    category: '',
  });

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(product);
    setProduct({ name: '', price: '', category: '' });
  };

  return (
    <div className="container mt-4">
      <form className="card p-4 shadow" onSubmit={handleSubmit}>
        <h4 className="mb-4 text-center text-info">Add New Product</h4>

        <div className="mb-3">
          <label className="form-label">Product Name</label>
          <input
            type="text"
            className="form-control"
            name="name"
            value={product.name}
            onChange={handleChange}
            placeholder="Enter product name"
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Price (₹)</label>
          <input
            type="number"
            className="form-control"
            name="price"
            value={product.price}
            onChange={handleChange}
            placeholder="Enter price"
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Category</label>
          <input
            type="text"
            className="form-control"
            name="category"
            value={product.category}
            onChange={handleChange}
            placeholder="Enter category"
            required
          />
        </div>

        <button type="submit" className="btn btn-success w-100">Add Product</button>
      </form>
    </div>
  );
};

export default ProductForm;

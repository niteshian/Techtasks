// src/axios/axiosInstance.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'https://localhost:7193/api', // Adjust base URL as per your backend
  headers: {
    'Content-Type': 'application/json',
  },
});

export default api;

import React from 'react';
import { Navigate } from 'react-router-dom';

function PrivateRoute({ children, requiredRole }) {
  const role = localStorage.getItem('role');

  if (role !== requiredRole) {
    // Redirect to login page if the user doesn't have the right role
    return <Navigate to="/login" />;
  }

  return children;
}

export default PrivateRoute;

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './PagesTemp/Home';
import Login from './PagesTemp/Login';
import Register from './PagesTemp/Register';
import AdminDashboard from './PagesTemp/AdminDashboard';
import CustomerDashboard from './PagesTemp/CustomerDashboard';
import Navbar from './PagesTemp/Navbar';
import PrivateRoute from './Routes/PrivateRoute';

function App() {
  return (
    <Router>
      <Navbar />
      <div className="container mt-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* Admin Routes */}
          <Route 
            path="/admin-dashboard" 
            element={
              <PrivateRoute requiredRole="admin">
                <AdminDashboard />
              </PrivateRoute>
            } 
          />
          
          {/* Customer Routes */}
          <Route 
            path="/customer-dashboard" 
            element={
              <PrivateRoute requiredRole="customer">
                <CustomerDashboard />
              </PrivateRoute>
            } 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

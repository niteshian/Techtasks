import axios from 'axios';

const api = axios.create({
  baseURL: 'https://localhost:7193/api', // Adjust base URL as per your backend
  headers: {
    'Content-Type': 'application/json', // Add default header for JSON content type
  },
});

export default api;


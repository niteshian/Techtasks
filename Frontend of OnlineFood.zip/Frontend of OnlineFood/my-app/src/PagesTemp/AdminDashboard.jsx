import React from 'react';

function AdminDashboard() {
  return (
    <div style={dashboardContainerStyles}>
      <div style={sidebarStyles}>
        <h3>Admin Dashboard</h3>
        <ul style={sidebarListStyles}>
          <li style={sidebarListItemStyles}>Manage Products</li>
          <li style={sidebarListItemStyles}>Orders</li>
          <li style={sidebarListItemStyles}>Settings</li>
        </ul>
      </div>
      <div style={contentStyles}>
        <h2>Welcome, Admin!</h2>
        <p>Here you can manage products, view orders, and more.</p>
        {/* You can add further admin functionalities like product listing, adding, deleting here */}
      </div>
    </div>
  );
}

const dashboardContainerStyles = {
  display: 'flex',
  gap: '20px',
  marginTop: '20px',
};

const sidebarStyles = {
  width: '200px',
  backgroundColor: '#f4f4f4',
  padding: '15px',
  borderRadius: '8px',
};

const sidebarListStyles = {
  listStyleType: 'none',
  padding: '0',
};

const sidebarListItemStyles = {
  padding: '10px 0',
  cursor: 'pointer',
};

const contentStyles = {
  flex: 1,
  backgroundColor: '#fff',
  padding: '20px',
  borderRadius: '8px',
};

export default AdminDashboard;

import React from 'react';

function CustomerDashboard() {
  return (
    <div style={dashboardStyles}>
      <div style={cardStyle}>
        <h1>Customer Dashboard</h1>
        <p>Welcome! You can view all available products below.</p>

        <div style={productListPlaceholder}>
          <p><strong>🛒 Product List will be displayed here.</strong></p>
          {/* Later, you can map through products here */}
        </div>
      </div>
    </div>
  );
}

const dashboardStyles = {
  display: 'flex',
  justifyContent: 'center',
  marginTop: '40px',
};

const cardStyle = {
  padding: '20px',
  width: '500px',
  backgroundColor: '#f9f9f9',
  borderRadius: '10px',
  boxShadow: '0 0 10px rgba(0,0,0,0.1)',
  textAlign: 'center',
};

const productListPlaceholder = {
  marginTop: '20px',
  padding: '10px',
  border: '1px dashed #ccc',
  borderRadius: '6px',
  backgroundColor: '#fff',
};

export default CustomerDashboard;

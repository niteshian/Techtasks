import React, { useState } from 'react';
import api from '../services/api'; // ✅ make sure this path is correct

function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/auth/login', {
        email: formData.email,
        password: formData.password
      });

      // Save token in localStorage or sessionStorage
      localStorage.setItem('token', res.data.token);

      alert('Login successful!');
    } catch (err) {
      console.error(err);
      alert('Invalid credentials. Please try again.');
    }
  };

  return (
    <div style={formContainerStyles}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit} style={formStyles}>
        <div style={inputGroupStyles}>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter your email"
            style={inputStyles}
          />
        </div>

        <div style={inputGroupStyles}>
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Enter your password"
            style={inputStyles}
          />
        </div>

        <button type="submit" style={submitButtonStyles}>
          Login
        </button>
      </form>
    </div>
  );
}

// Styling
const formContainerStyles = {
  width: '300px',
  margin: '0 auto',
  padding: '20px',
  backgroundColor: '#f9f9f9',
  borderRadius: '8px',
};

const formStyles = {
  display: 'flex',
  flexDirection: 'column',
  gap: '15px',
};

const inputGroupStyles = {
  display: 'flex',
  flexDirection: 'column',
};

const inputStyles = {
  padding: '10px',
  marginTop: '5px',
  borderRadius: '4px',
  border: '1px solid #ccc',
};

const submitButtonStyles = {
  padding: '10px',
  backgroundColor: '#007BFF',
  color: '#fff',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
};

export default Login;

import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav style={navbarStyles}>
      <ul style={navListStyles}>
        <li style={navItemStyles}>
          <Link to="/">Home</Link>
        </li>
        <li style={navItemStyles}>
          <Link to="/login">Login</Link>
        </li>
        <li style={navItemStyles}>
          <Link to="/register">Register</Link>
        </li>
        <li style={navItemStyles}>
          <Link to="/admin-dashboard">Admin Dashboard</Link>
        </li>
        <li style={navItemStyles}>
          <Link to="/customer-dashboard">Customer Dashboard</Link>
        </li>
      </ul>
    </nav>
  );
}

const navbarStyles = {
  backgroundColor: 'pink',
  padding: '10px',
};

const navListStyles = {
  display: 'flex', // Makes the list horizontal
  listStyleType: 'none',
  margin: 0,
  padding: 0,
};

const navItemStyles = {
  marginRight: '20px',
};

export default Navbar;

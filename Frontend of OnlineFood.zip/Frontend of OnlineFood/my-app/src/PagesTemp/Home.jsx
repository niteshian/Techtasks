import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Food Ordering System</h1>
      <div style={{ marginTop: '30px' }}>
        <Link to="/login" style={buttonStyle}>Login</Link>
        <Link to="/register" style={buttonStyle}>Register</Link>
      </div>
    </div>
  );
}

const buttonStyle = {
  display: 'inline-block',
  margin: '10px 20px', // <-- THIS LINE adds spacing between buttons
  padding: '10px 20px',
  backgroundColor: '#007bff',
  color: '#fff',
  textDecoration: 'none',
  borderRadius: '5px',
};

export default Home;
